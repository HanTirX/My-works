package com.example.tipcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tipcalculator.databinding.ActivityMainBinding
import kotlin.math.ceil

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.calculateButton.setOnClickListener { calculateTip() }
    }

    private fun calculateTip() {
        val cost = binding.costOfService.text.toString().toDouble()
        val selectedId = binding.tipOptions.checkedRadioButtonId
        val percentage = when(selectedId){
            R.id.option_ten_percent -> 0.1
            R.id.option_seven_percent -> 0.07
            else -> 0.05

        }
        var tip = cost*percentage
        val round = binding.roundSwitch.isChecked
        if(round){
            tip = ceil(tip)
        }
        binding.tipResult.text = tip.toString()
    }
}