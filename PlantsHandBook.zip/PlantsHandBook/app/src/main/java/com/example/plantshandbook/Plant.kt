package com.example.plantshandbook

data class Plant(val imageId: Int, val title: String)
